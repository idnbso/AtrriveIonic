import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  templateUrl: 'build/pages/home/home.html'
})
export class HomePage {
  public enteredAddress: string;
  public geocoder: google.maps.Geocoder;
  public results: Array<any>;
  
  constructor() {
    this.enteredAddress = "";
    this.geocoder = new google.maps.Geocoder();
    this.results = [];
  }
  
  onSubmit() {
    
    this.results = [];
    
    this.geocoder.geocode( {address: this.enteredAddress}, (destination, status) => {
      if (status === google.maps.GeocoderStatus.OK) { // destination address found by the geocoder
        this.results = destination.slice(0, 4); // show top 4 results
      }
      else if (status === google.maps.GeocoderStatus.ZERO_RESULTS)
      { // destination address not found by the geocoder
        alert("Destination not found");
      }
      else {
        console.log(status);
      }
    })
  }
}
